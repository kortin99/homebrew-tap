package dbm

type Group struct {
	Name      string
	Pattern   string
	BlackList []string
}
